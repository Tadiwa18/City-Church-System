
package com.citychurch.servlet;

import com.citychurch.model.User;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author theop
 */

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       //accept username and password(question 2.1)
       String username = request.getParameter("username");
       String password = request.getParameter("password");
       
       response.setContentType("text/html");
       PrintWriter out = response.getWriter();
       
       
       //validating fields (question 2.2)
       if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
           
           out.println("<h3>Error: Username and password are required </h3>");
           return;
       }
       
       //checking if username already exists
       User user = UserRegistrationServlet.users.get(username);
       
       if (user == null) {
           out.println("<h3>Error: username does not exist </h3>");
           return;
       }
       
       if (!user.getPassword().equals(password)) {
           out.println("<h3>Error: Incorrect Password </h3>");
           return;
       }
       
       
       //validating user role
       if (!user.getRole().equals("member") && !user.getRole().equals("leader")) {
           out.println("<h3>Error: Invalid user role. </h3>");
           return;
       }
       
       //creating http session(question2.3)
       HttpSession session = request.getSession();
       
       
       //storing the authenticated user
       session.setAttribute("user", user);
       
       
       //successful login response(question 2.4)
       out.println("<h3>Login Succcessful</h3>");
       out.println("<p>Welcome " + user.getUsername() + "</p>");
       out.println("<p>Role: " + user.getRole() + "</p>");
       
       out.println("<script>");
       out.println("setTimeout(function() {");
       if (user.getRole().equals("leader")) {
           out.println(" window.location.href = 'notification.jsp';");
       } else {
           out.println(" window.location.href = 'home.jsp';");
       }
       
       out.println("}, 2000);");  //redirect in 2 seconds
       out.println("</script>");
        
    }
}
