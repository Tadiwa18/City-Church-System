
package com.citychurch.servlet;

import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 *
 * @author theop
 */

@MessageDriven(mappedName = "jms/ChurchNotifications")
public class JMSNotificationConsumer implements MessageListener {
    
    @Override
    public void onMessage(Message message) {
        
        try {
            if (message instanceof TextMessage) {
                String notification = ((TextMessage) message).getText();
                
                //sending JMS notification to WebSocket clients
                ChatEndpoint.broadcast(notification);
            }
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
    
}
