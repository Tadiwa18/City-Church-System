
package com.citychurch.servlet;

/**
 *
 * @author theop
 */


import com.citychurch.model.User;
import java.io.IOException;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





@WebServlet("/sendNotification")
public class NotificationServlet extends HttpServlet {

    @Resource(lookup = "jms/ChurchConnectionFactory")
    private ConnectionFactory connectionFactory;

    @Resource(lookup = "jms/ChurchNotifications")
    private Queue notificationQueue;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get logged-in user
        HttpSession session = request.getSession(false);
        User loggedInUser = null;

        if (session != null) {
            loggedInUser = (User) session.getAttribute("user");
        }

        // Make sure user is logged in
        if (loggedInUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Only leaders can send notifications
        if (!"leader".equals(loggedInUser.getRole())) {
            response.sendRedirect("home.jsp");
            return;
        }

        // Get notification text
        String notification = request.getParameter("notification");

        if (notification == null || notification.trim().isEmpty()) {
            response.sendRedirect("notification.jsp?error=empty");
            return;
        }

        try (JMSContext context = connectionFactory.createContext()) {

            context.createProducer().send(
                    notificationQueue,
                    notification.trim()
            );

            response.sendRedirect("notification.jsp?success=true");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("notification.jsp?error=send");
        }
    }
}
