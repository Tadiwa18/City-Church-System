package com.citychurch.servlet;

import com.citychurch.model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author theop
 */

@WebServlet("/register")
public class UserRegistrationServlet extends HttpServlet {
    
    //we are going to use a hashmap to store users in memory (q1.3)
    public static final Map<String, User> users = new HashMap<>();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        //question 1.1
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        
        //question 1.2 validating empty fields
        if(username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()
                || role == null || role.trim().isEmpty()) {
                
                out.println("<h3> Error: All fields are required. </h3>");
                return;
            }
        
        
        //validating user role
        if (!role.equals("member") && !role.equals("leader")) {
            
            out.println("<h3>Error: Invalid user role.</h3>");
            return;
        }
        
        
        //checking if username already exists
        if(users.containsKey(username)) {
            
            out.println("<h3> Error: Username already exissts. </h3>");
            return;
        }
        
        
        //creating and storing of the user
        User user = new User(username, password, role);
        users.put(username, user);
        
        out.println("<h3> Registration Successful </h3>");
        out.println("<p> Welcome " + username + "</p>");
        
       out.println("<script>");
       out.println("setTimeout(function() {");
       out.println(" window.location.href = 'login.jsp';");
       out.println("}, 2000);");  //redirect in 2 seconds
       out.println("</script>");
        
        
    }
    
    
}
