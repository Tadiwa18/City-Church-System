
package com.citychurch.servlet;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.server.ServerEndpoint;
import javax.websocket.Session;

/**
 *
 * @author theop
 */

@ServerEndpoint("/chat")
public class ChatEndpoint {
    
    //storing all our connected users
    private static final Set<Session> users = new HashSet<>();
    
    
    //this is called when a client connects 
    @OnOpen
    public void onOpen(Session session){
        users.add(session);
        
        System.out.println("User connected");
    }
    
    @OnClose
    public void onClose(Session session) {
        users.remove(session);
        
        System.out.println("User disconnected");
    }
    
    
    @OnMessage
    public void broadcastMessage(String message, Session session) {
        broadcast(message);
    }
    
    
    public static void broadcast(String message) {
        
          for(Session user : users) {
            try {
                user.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
         
    }
    
}
