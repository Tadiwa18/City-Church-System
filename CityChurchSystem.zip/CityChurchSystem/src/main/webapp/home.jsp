<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>City Church Home</title>

        <style>
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                text-align: center;
            }

            .container {
                width: 80%;
                max-width: 1000px;
                min-height: 500px;
                margin: 30px auto;
                padding-top: 30px;
                background-color: #eef8fb;
                border: 2px solid #ddd;
            }

            h1 {
                color: #20aeda;
                margin-top: 20px;
                font-size: 25px;
            }

            h2 {
                color: #20aeda;
                margin-top: 20px;
            }

            .view-button {
                display: inline-block;
                margin-top: 80px;
                padding: 13px 25px;
                background-color: #20b5dc;
                color: white;
                border: none;
                border-radius: 25px;
                font-size: 19px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 0 3px 6px #bbb;
            }

            .view-button:hover {
                background-color: #159fc3;
            }

            #notifications {
                width: 60%;
                margin: 40px auto;
                text-align: left;
            }

            .notification {
                padding: 12px;
                margin-bottom: 10px;
                background-color: white;
                border: 1px solid #ddd;
                border-radius: 6px;
            }

            .noNotifications {
                text-align: center;
                color: #777;
            }
        </style>
    </head>

    <body>

        <div class="container">

            <h1>City Church</h1>

            <h2>Home</h2>

            <button class="view-button" onclick="showNotifications()">
                View Notifications
            </button>

            <div id="notifications" style="display: none;">

                <p class="noNotifications">
                    No notifications received yet.
                </p>

            </div>

        </div>

        <script>

            // Connecting to the WebSocket endpoint
            var socket = new WebSocket(
                "ws://" + window.location.host
                + "${pageContext.request.contextPath}/chat"
            );

            // Receiving a notification
            socket.onmessage = function(event) {

                var notifications =
                        document.getElementById("notifications");

                // Remove the default message
                var defaultMessage =
                        notifications.querySelector(".noNotifications");

                if (defaultMessage) {
                    defaultMessage.remove();
                }

                // Create a notification
                var notification =
                        document.createElement("p");

                notification.className = "notification";
                notification.textContent = event.data;

                // Add notification to the page
                notifications.appendChild(notification);
            };

            // Show notifications
            function showNotifications() {

                var notifications =
                        document.getElementById("notifications");

                notifications.style.display = "block";
            }

            // Show WebSocket connection error
            socket.onerror = function() {
                console.log("WebSocket connection error");
            };

        </script>

    </body>
</html>
