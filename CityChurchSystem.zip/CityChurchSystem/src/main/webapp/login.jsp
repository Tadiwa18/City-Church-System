
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>

<html>
    <head>
        <title>City Church Login</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <style>
            body {
                margin: 0;
                text-align: center;
            }
            
            .container {
                width: 80%;
                height: 500px;
                margin: 30px auto;
                padding-top: 30px;
                padding-bottom: 30px;
                border: 2px solid #ddd;
                border-radius: 8px;
                background-color: #eef8fb;
            }
            
            h1 {
                color: #20aeda;
                margin-top: 20px;
                font-size: 25px;
            }
            
            h2 {
                color: #20aeda;
                margin-bottom: 40px; 
            }
            
            
            input[type="text"], input[type="password"] {
                display: block;
                width: 200px;
                padding: 12px;
                margin: 15px auto;
                border: 1px solid #ddd;
                border-radius: 6px;
                text-align: center;
            }
            
            input[type="submit"] {
                width: 120px;
                padding: 13px;
                margin-top: 35px;
                background-color: #20b5dc;
                color: white;
                border: none;
                border-radius: 25px;
                font-size: 19px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 0 3px 6px #bbb;
            }
            
            input[type="submit"]:hover {
                background-color: #159fc3;
            }
            
            
            .registerButton {
                display: inline-block;
                width: 100px;
                padding: 13px;
                margin-top: 15px;
                margin-bottom: 15px;
                background-color: white;
                color: #20aeda;
                border: 2px solid #20b5dc;
                border-radius: 25px;
                font-size: 19px;
                font-weight: bold;
                text-decoration: none;
                box-shadow: 0 3px 6px #ddd;
            }
            
            .registerButton:hover {
                background-color: #20b5dc;
                color: white;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>City Church Notification System</h1>
            <h2>User Login</h2>
        
        <form action= "login" method="post">
            <label>Username:</label>
            <input type="text" name="username" placeholder="username">
            <br>
            
            <label>Password:</label>
            <input type="password" name="password" placeholder="password">
            <br>
            
            <input type="submit" value="Login">
            
        </form>
            
            <a href="register.jsp" class="registerButton">Register</a>
            
        </div>
        
    </body>
</html>
