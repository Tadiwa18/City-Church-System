<%@page import="com.citychurch.model.User"%>

<%
    // Get the logged-in user from the session
    User loggedInUser = (User) session.getAttribute("user");

    // Check if the user is logged in
    if (loggedInUser == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    // Check if the user is a church leader
    if (!loggedInUser.getRole().equals("leader")) {
        response.sendRedirect("home.jsp");
        return;
    }
%>

<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Notifications</title>

        <style>
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                text-align: center;
            }

            .container {
                width: 80%;
                max-width: 1000px;
                height: 550px;
                margin: 30px auto;
                padding-top: 30px;
                background-color: #eef8fb;
                border: 2px solid #ddd;
            }

            h1 {
                color: #20aeda;
                margin-top: 20px;
                font-size: 25px;
            }

            h2 {
                color: #20aeda;
                margin-top: 20px;
            }

            h3 {
                margin-top: 80px;
                color: #333;
                font-size: 16px;
            }

            textarea {
                width: 380px;
                height: 100px;
                margin-top: 10px;
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 8px;
                resize: none;
                font-family: Arial, sans-serif;
            }

            .send-button {
                display: block;
                width: 200px;
                padding: 13px;
                margin: 45px auto 0;
                background-color: #20b5dc;
                color: white;
                border: none;
                border-radius: 25px;
                font-size: 19px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 0 3px 6px #bbb;
            }

            .send-button:hover {
                background-color: #159fc3;
            }
        </style>
    </head>

    <body>

        <div class="container">

            <h1>City Church Notification System</h1>

            <h2>Server-side</h2>

            <p>Welcome, Church Leader <%= loggedInUser.getUsername() %></p>

            <h3>Write a notification to send to the users</h3>
            
            <form action="sendNotification" method="post">
                <textarea name = "notification" placeholder="Write notification here..." required></textarea>

            <button type="submit" class="send-button">
                Send Notification
            </button>
            </form>

            

        </div>

    </body>
</html>