<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>

<html>
    <head>
        <title>City Church Registration</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <style>
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                text-align: center;
            }

            .container {
                width: 80%;
                max-width: 1000px;
                height: 550px;
                margin: 30px auto;
                padding-top: 30px;
                background-color: #eef8fb;
                border: 2px solid #ddd;
            }

            h1 {
                color: #20aeda;
                margin-top: 20px;
                font-size: 25px;
            }

            h2 {
                color: #20aeda;
                margin-bottom: 40px;
            }

            input[type="text"],
            input[type="password"],
            select {
                display: block;
                width: 200px;
                padding: 12px;
                margin: 15px auto;
                border: 1px solid #ddd;
                border-radius: 6px;
                text-align: center;
                background-color: white;
            }

            input[type="submit"] {
                width: 150px;
                padding: 13px;
                margin-top: 30px;
                background-color: #20b5dc;
                color: white;
                border: none;
                border-radius: 25px;
                font-size: 19px;
                font-weight: bold;
                cursor: pointer;
                box-shadow: 0 3px 6px #bbb;
            }

            input[type="submit"]:hover {
                background-color: #159fc3;
            }

            .login-button {
                display: inline-block;
                width: 150px;
                padding: 13px;
                margin-top: 15px;
                background-color: white;
                color: #20aeda;
                border: 2px solid #20b5dc;
                border-radius: 25px;
                font-size: 19px;
                font-weight: bold;
                text-decoration: none;
                box-shadow: 0 3px 6px #ddd;
            }

            .login-button:hover {
                background-color: #20b5dc;
                color: white;
            }
        </style>
    </head>

    <body>

        <div class="container">

            <h1>City Church Notification System</h1>

            <h2>Registration</h2>

            <form action="register" method="post">

                <input type="text"
                       name="username"
                       placeholder="Username"
                       required>

                <input type="password"
                       name="password"
                       placeholder="Password"
                       required>

                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="member">Member</option>
                    <option value="leader">Leader</option>
                </select>

                <input type="submit" value="Register">

            </form>

            <a href="login.jsp" class="login-button">Login</a>

        </div>

    </body>
</html>
